from GameOfLife import GameOfLife

game= GameOfLife(init_alive_cells_num=50, game_turns=100)
game.init_game()

